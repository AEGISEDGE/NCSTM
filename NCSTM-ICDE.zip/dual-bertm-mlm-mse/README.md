# Gaussian Softmax Model

#### 介绍
基于VAE构架的NTM，GSM

#### 软件架构
基于variational auto encoder构架，loss是交叉熵损失

Encoder：MLP + ReLU -> 2x Linear-> loc, logscale

Decoder：Normal(loc, logscale) + Softmax -> +beta -> Log