# -*- coding: utf-8 -*-
from torch.utils.data import Dataset
import math, sys, pickle, torch
#from utils import *

#====================================================================================================================================================
# Corpus object
# class TMCorpus(Dataset):
#     def __init__(self, vocabulary_size, data_path, validation=False, prop=None, loader=None):
#         #data_path: path route for train.feat and test.feat
#         # self.device=device
#         self.vocabulary_size=vocabulary_size
#         self.doc_vec_set=[]
#         self.lable_set=[]
#         #
#         self.doc_list = pickle.load(open(data_path, 'rb'))
#         doc_cnt = len(self.doc_list)
#         if validation:
#             self.doc_list = self.doc_list[:int(prop*doc_cnt)] # Scale dataset into validation set
#             self.doc_cnt = len(self.doc_list)
#         else:
#             self.doc_cnt = len(self.doc_list)
#         self.doc_word_cnt_list = []
#         for i,doc in enumerate(self.doc_list):
#             self.doc_word_cnt_list.append(self.count_word(doc['clean_bow']))
#         #
#         self.loader = loader
#         self.doc_count = i

#     def count_word(self, clean_bow):
#         return sum([tf for _, tf in clean_bow])

#     def __len__(self):
#         return self.doc_cnt
    
#     def bow2tensor(self, bow):
#         vec = torch.zeros(self.vocabulary_size)
#         for token,tf in bow:
#             vec[token]=tf
#         return vec
    
#     def __getitem__(self, index):
#         doc = self.doc_list[index]
#         return doc['text'], self.bow2tensor(doc['clean_bow']), self.doc_word_cnt_list[index], doc['label'] # Return: text, bow, bow_word_cnt, label

class TMCorpus(Dataset):
    def __init__(self, 
                corpus_obj,
                vocabulary_size,
                split=None,
                data_flg=None):
        super().__init__()
        self.doc_list=[]
        # read corpus file
        corpus = corpus_obj
        # get corpus length
        total_length = len(corpus)
        # Split file docs into desired part
        # Unspecified setting
        if split==None:
            self.doc_list=corpus
        elif 0.0< split <1.0:
            pivot = int(split * total_length)
            if data_flg=='train':# Training set split
                train = corpus[:pivot]
                self.doc_list=train
            elif data_flg=='val':# Validation set split
                val = corpus[pivot:]
                self.doc_list=val
            else:
                print('Invalid options for building dataset.')
                sys.exit()
        else:
            print('Invalid value for train_split or val_split')
            sys.exit()
        # 
        self.vocabulary_size=vocabulary_size
        self.clength = len(self.doc_list)
        self.flg=data_flg

    def __len__(self):
        return len(self.doc_list)

    def count_word(self, clean_bow):
        return sum([tf for _, tf in clean_bow])
    
    def bow2tensor(self, bow):
        vec = torch.zeros(self.vocabulary_size)
        for (token,tf) in bow:
            vec[token]=tf
        return vec
    
    def __getitem__(self, index):
        doc = self.doc_list[index]
        # Return: text, bow, bow_word_cnt, label, other metadata can be retrieved either
        return doc['text'], self.bow2tensor(doc['bow']), doc["bow_word_cnt"]