# -*- coding: utf-8 -*-
import argparse, sys, os, pickle, math, time, csv, portalocker, random
import torch, transformers
import pytorch_lightning as pl

from model import NSCTM as TopicModel
from dataset import TMCorpus

from pytorch_lightning.callbacks import Callback, ModelCheckpoint
from pytorch_lightning.callbacks.early_stopping import EarlyStopping
from pytorch_lightning.loggers import TensorBoardLogger

#Requirement:
# matplotlib, seaborn, panda, keops, geomloss

import numpy as np
import matplotlib.pyplot as plt
# import seaborn as sns
# import pandas as pd

from torch.utils.data import DataLoader
from prefetch_generator import BackgroundGenerator
# from sentence_transformers import SentenceTransformer
from transformers import AutoTokenizer, AutoModel, BertTokenizer, BertForMaskedLM

from palmettopy.palmetto import Palmetto
from datetime import datetime

#====================================================================================================================================================
# Note:

class DataLoaderX(DataLoader):
    def __iter__(self):
        return BackgroundGenerator(super().__iter__()) 
#====================================================================================================================================================
def Get_args():
    parser = argparse.ArgumentParser(description='NSCTM parameters description.')
    parser.add_argument("--enc-plm-select", default='bert-base', type=str,
        help="The encoder pretrain language model option.")
    parser.add_argument("--dec-plm-select", default='bert-base', type=str,
        help="The decoder pretrain language model option.")
    parser.add_argument("--theta-actf", default='softmax', type=str,
        help="The activating function for n_theta.")
    parser.add_argument('--n-hidden', type=int, default=256, metavar='N', 
        help="The size of hidden units of encoder linear")
    parser.add_argument('--enc-lr', type=float, default=1e-3, metavar='N', 
        help="The learning rate of encoder network.")
    parser.add_argument('--dec-lr', type=float, default=1e-3, metavar='N', 
        help="The learning rate of decoder network.")
    parser.add_argument('--topics', type=int, default=50, metavar='N',
        help="The amount of topics to be discover")
    parser.add_argument('--batch-size', type=int, default=128, metavar='N',
        help="Training batch size.")
    parser.add_argument('--disablerapidload', action='store_true',
        help="Flag for disable RAPID load corpus from previous binary file.")
    parser.add_argument('--max-epochs', type=int, default=1000, metavar='N',
        help="Alternative epoch size for wake sleep algorithm")
    parser.add_argument('--patience', type=int, default=20, metavar='N',
        help="patience for earlystop.")
    parser.add_argument('--rapid', action='store_true', default=True,
        help="Flag for enable rapid reloading dataset.")
    parser.add_argument('--data-path', default='data/processed_20news/', metavar='N',
        help="Directory for corpus. Default is preprocessed 20newsgroup corpus.")
    parser.add_argument('--topk', type=int, default=10, metavar='N',
        help="Top-k word for Topic Diversity Sinkhorn Regularization.")
    parser.add_argument('--measure', type=str, default='npmi,cp', metavar='N',
        help="Measurement for topic coherence.")
    parser.add_argument('--precision', type=str, default='high', metavar='N',
        help="Measurement for topic coherence.")
    parser.add_argument('--note', type=str, default='None', metavar='N',
        help="Note for experiments.")
    parser.add_argument('--seed', type=int, default=0, metavar='N',
        help="Set seed for all.")
    parser.add_argument('--rndseed', action="store_true", help="Enable auto random seed generation.")
    parser.add_argument('--savckpt', action="store_true", help="Enable automatic checkpoint save.")
    parser.add_argument('--cyclelen', type=int, default=20, metavar='N',
        help="The number of iteration for each cycle.")
    parser.add_argument('--cap', type=float, default=0.5, metavar='N',
        help="Proportion for uprising steps.")
    parser.add_argument('--mlmprob', type=float, default=0.15, metavar='N',
        help="Probability for masked language model.")
    parser.add_argument('--mlmweight', type=float, default=1.0, metavar='N',
        help="Weight for MLM loss.")
    parser.add_argument('--recweight', type=float, default=1.0, metavar='N',
        help="Weight for MSE loss.")
    parser.add_argument('--tau', type=float, default=1.0, metavar='N',
        help="Initial value for gumbel softmax function") 
    parser.add_argument('--ftv', type=float, default=0.01, metavar='N',
        help="Final value for gumbel softmax function") 
    parser.add_argument('--wdecay', type=float, default=0.5, metavar='N',
        help="Weight decay for optimizer.") 
    parser.add_argument('--maxiter', type=int, default=100, metavar='N',
        help="Max cycle iteration.")
    parser.add_argument('--tsteps', type=int, default=500, metavar='N',
        help="Max step for tau decending process.")
    parser.add_argument('--bg', action='store_false',
        help="Flag for disable progress bar and model summary in pytorch lightning.")
    parser.add_argument('--es', action='store_true',
        help="Flag for early-stop training strategy.")
    parser.add_argument('--nobetaembedding', action='store_true',
        help="Flag for disable pretrained word embedding in beta.")
    parser.add_argument('--tb', action='store_true',
        help="Flag for enable tensorboard record.")
    parser.add_argument('--dataset', default='20news', metavar='N',
        help="Directory for corpus. Valid choice: 20news, yelp, allthenews1, wikitext2")
    return parser.parse_args()

# ------------------------------------------------------------------------------------
# Load pre-download pretrain language model and tokenizer path
def Get_plm(name, device):
    BASE_PATH = "/home/lyliu/data/huggingface_model/"
    plm_dir= {
        "bert-base": BASE_PATH + "bert-base-uncased",
        "bert-large": BASE_PATH + "bert-large-uncased",
        "roberta-base": BASE_PATH + "roberta-base",
        "roberta-large": BASE_PATH + "roberta-large",
        "t5-base": BASE_PATH + "t5-base",
        "t5-large": BASE_PATH + "t5-large",
        "bart-base": BASE_PATH + "bart-base",
        "bart-large": BASE_PATH + "bart-large"
        }
    if name not in plm_dir.keys():
        print("Invalid selection for plm.")
        os._exit(0)
    PLM_PATH = plm_dir[name]
    return PLM_PATH

# ------------------------------------------------------------------------------------

def build_wordembedding_from_dict(wordembedding_dict, id2word):
    vec_list = []
    # sorted(tmp_list, key = lambda s:s[:][1], reverse=True)
    idlist = list(id2word.keys())
    idlist.sort()
    for idx in idlist:
        word = id2word[idx]
        if word not in wordembedding_dict.keys():
            embedding = wordembedding_dict['unk']
        else:
            embedding = wordembedding_dict[word]
        vec_list.append(embedding)
    return vec_list

# ------------------------------------------------------------------------------------

# Cycle annealing object
class Cycle_annealing(object):
    def __init__(self, cyclelen, proportion=0.5, max_iter=100):
        self.n_iter = 0
        self.pivot = int(cyclelen * proportion)
        self.cyclelen = cyclelen
        self.value_list = np.linspace(start=0.0, stop=1.0, num=self.pivot)
    
    def Get_value_len(self):
        return len(self.value_list)

    def Get_weight(self):
        i = 0
        while True:
            if i < self.pivot:
                yield self.value_list[i]
            elif i < self.cyclelen:
                yield 1.0
            i += 1
            i = i % self.cyclelen

# ------------------------------------------------------------------------------------

def Build_tmcorpus(data_path, vocabulary_size, name):
	corpus = pickle.load(open(data_path + os.sep + 'corpus.bin', 'rb'))
	train = corpus['train']
	test = corpus['test']
	val=None
	if 'val' in corpus.keys():
		val = corpus['val']
	return {"name":name,
		"train":TMCorpus(corpus_obj=train,vocabulary_size=vocabulary_size,split=0.8,data_flg="train") if val==None else TMCorpus(corpus_obj=train,vocabulary_size=vocabulary_size,split=None,data_flg="train"),
		"val":TMCorpus(corpus_obj=train,vocabulary_size=vocabulary_size,split=0.8,data_flg="val") if val==None else TMCorpus(corpus_obj=val,vocabulary_size=vocabulary_size, split=None, data_flg="val"),
		"test":TMCorpus(corpus_obj=test,vocabulary_size=vocabulary_size,split=None,data_flg="test")}

class SafeCSVWriter:
    def __init__(self, filename, columns):
        self.filename = filename
        self.columns = columns
        self._ensure_header()

    def _ensure_header(self):
        """检查并写入表头（线程安全）"""
        if not os.path.exists(self.filename):
            # 文件不存在时创建并写入表头
            with open(self.filename, 'w') as f:
                portalocker.lock(f, portalocker.LOCK_EX)
                writer = csv.DictWriter(f, fieldnames=self.columns)
                writer.writeheader()
                portalocker.unlock(f)

    def append_row(self, row_data):
        """追加单行数据（进程安全）"""
        with open(self.filename, 'a') as f:
            # 获取独占锁，阻塞直到锁可用
            portalocker.lock(f, portalocker.LOCK_EX)
            writer = csv.DictWriter(f, fieldnames=self.columns)
            writer.writerow(row_data)
            # 锁会在文件关闭时自动释放，但显式释放更安全
            portalocker.unlock(f)

class TauScheduler(Callback):
    def __init__(self, initial_value=1.0, final_value=0.5, total_steps=None):
        super().__init__()
        self.initial_value = initial_value
        self.final_value = final_value
        self.total_steps = total_steps
        self.current_step = 0
        self.tau = initial_value

    def on_train_batch_start(self, trainer, pl_module, batch, batch_idx):
        if self.total_steps is not None and self.current_step >= self.total_steps:
            return
        
        fraction = min(1.0, float(self.current_step) / self.total_steps)
        self.tau = self.initial_value - fraction * (self.initial_value - self.final_value)
        
        # 将系数传递给模型
        pl_module.tau = self.tau
        
        self.current_step += 1
    
    # def on_train_epoch_start(self, trainer, pl_module):
    #     if self.total_steps is not None and self.current_step >= self.total_steps:
    #         return
        
    #     fraction = min(1.0, float(self.current_step) / self.total_steps)
    #     self.coefficient = self.initial_coefficient - fraction * (self.initial_coefficient - self.final_coefficient)
        
    #     # 将系数传递给模型
    #     pl_module.coefficient = self.coefficient
        
    #     self.current_step += 1
# ------------------------------------------------------------------------------------

dataset_map = {
    '20news': "data/20news/processed_20news",
    'yelp': "data/yelp-process",
    'allthenews1': "data/all-the-news1/allnews1-process",
    'wikitext2': "data/wikitext-2-v1"
}
# ------------------------------------------------------------------------------------

#==================================================================================================================================================
def main():
    # Get args
    args=Get_args()
    if args.rndseed:
        seed_value = random.randint(0, 65535)
    else:
        seed_value = args.seed
    pl.seed_everything(seed_value)
    # GPU precision setting
    torch.set_float32_matmul_precision(args.precision)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    #Load dataset
    if args.dataset in dataset_map.keys():
        data_path=dataset_map[args.dataset]
        data_name = args.dataset
    else:
        print("Invalid dataset! Valid choice: 20news,yelp,allthenews1,wikitext2")
        sys.exit()
    # Task time string record
    # 获取当前日期和时间
    now = datetime.now()
    # 格式化日期时间为“年-月-日-时-分-秒”
    time_formatted_now = now.strftime("%Y-%m-%d-%H-%M-%S")
    # Load vocab object and get vocabulary information
    vocab = pickle.load(open(data_path + os.sep + "vocab.bin", 'rb'))
    word2id = vocab.token2id
    vocabulary_size=len(word2id)
    assert vocabulary_size==len(word2id), "Unequal length of vocabulary size"
    id2word = {id:word for word,id in word2id.items()}
    print("===========================================================================================================")
    print('Encoder hidden units: %d, topic number: %d, vocab size: %d' % (args.n_hidden, args.topics, vocabulary_size))
    # Rapid reload dataset object:
    if os.path.exists("corpus_obj-" + data_name + ".bin") and not args.disablerapidload:
        corpus = pickle.load(open("corpus_obj-" + data_name + ".bin", 'rb'))
        corpus_name = corpus["name"]
        if corpus_name != data_name:
            # Re-build corpus
            print("Re-build corrupted corpus... ...")
            corpus = Build_tmcorpus(data_path, vocabulary_size, data_name)
            pickle.dump(corpus, open("corpus_obj-" + data_name + ".bin", 'wb'))
            # Process corpus and save
        else:
            print("*** Rapid reload dataset object from previously dumped file. ***")
    else:
        print("Processing dataset file... ...")
        # corpus = Build_corpus(args.data_path, vocabulary_size)
        corpus = Build_tmcorpus(data_path, vocabulary_size, data_name)
        pickle.dump(corpus, open("corpus_obj-" + data_name + ".bin", 'wb'))
    train_dataset = corpus["train"]
    validation_dataset = corpus["val"]
    test_dataset  = corpus["test"]
    #==========================================================================
    #==========================================================================
    # Build dataloader
    print("Building dataLoader... ...")
    train_dataloader = DataLoaderX(train_dataset, 
        batch_size=args.batch_size, 
        shuffle=True, 
        num_workers=8, 
        pin_memory=True, 
        drop_last=False)
    validation_dataloader = DataLoaderX(validation_dataset, 
        batch_size=args.batch_size, 
        shuffle=False, 
        num_workers=8, 
        pin_memory=True,
        drop_last=False)
    test_dataloader  = DataLoaderX(test_dataset, 
        batch_size=args.batch_size, 
        shuffle=False, 
        num_workers=8, 
        pin_memory=True, 
        drop_last=False)
    #=========================================================================
    #Build model
    #=========================================================================
    # Load Pretrain Language Model module
    print("Loading pretrained language model... ...")
    os.environ["TOKENIZERS_PARALLELISM"] = "true"
    enc_plm_path = Get_plm(args.enc_plm_select, device)
    dec_plm_path = Get_plm(args.dec_plm_select, device)
    # ------------------------------------------------------------------------------------
    # Load pretrained word embeddings
    word2embedding_dict = pickle.load(open("/home/lyliu/data/embedding/word2vec_glove.6B.100d.txt.bin", 'rb'))
    wordembedding_mat = build_wordembedding_from_dict(word2embedding_dict, id2word)
    # ------------------------------------------------------------------------------------
    # Callback functions for pytorch lightning
    # Tensorboard loggers
    if args.tb:
        logger = TensorBoardLogger('tb_logs', name='NSCTM')
    # Callback settings
    # If early-stop enabled
    if args.es:
        callback_list = [ EarlyStopping(monitor="val_loss", mode="min", patience = args.patience, check_on_train_epoch_end=False) ]
    else:
        callback_list = []
    # Checkpoint settings
    if args.savckpt:
        if not os.path.exists('sav'):
            os.makedirs('sav')
        checkpoint_callback = ModelCheckpoint(
            monitor='val_loss',
            dirpath="sav" + os.sep ,
            filename='nsctm-{epoch:02d}-{val_loss:.3f}.bin',
            save_top_k=5,
            mode='min',
            save_last=True,
            save_weights_only=True)
        callback_list.append(checkpoint_callback)
    # ------------------------------------------------------------------------------------
    # Automatic topic coherence
    tc = Palmetto("http://127.0.0.1:7777/service/", timeout=60)
    # ------------------------------------------------------------------------------------
    # Build topic model
    print("Building model... ...")
    # Configuration for Cycle annealing
    ca = Cycle_annealing(args.cyclelen, args.cap, args.maxiter)
    # Run identifier
    run_id = {"topics":args.topics, 
            "h":args.n_hidden,
            "bs":args.batch_size, 
            'note':args.note,
            'theta_actf':args.theta_actf,
            'wdecay':args.wdecay,
            # "lambda":args.weightlambda,
            "p":args.patience,
            "elr":args.enc_lr,
            "dlr":args.dec_lr,
            "eplm-":args.enc_plm_select,
            "dplm-":args.dec_plm_select,
            "cl":args.cyclelen,
            "cp":args.cap,
            "mi":args.maxiter,
            "mlmprob":args.mlmprob,
            "mw":args.mlmweight,
            "rw":args.recweight,
            "tstep":args.tsteps,
            "es":args.es,
            "topk":args.topk,
            "tau":args.tau,
            "ftv":args.ftv,
            "seed":seed_value}
    run_id_str = data_name + "_" + "_".join([title + str(values) for title,values in run_id.items()])
    if len("topic_files" + os.sep + run_id_str + "_topic-" + str(000).zfill(3) + ".txt")>=255:
        print("Save file name is too long.")
        sys.exit()
    # Training metrics writer
    columns = "dataset time topics hidden plm-select theta_actf topk tstep tau ftv p cl cp mi mlmprob mw rw bs elr dlr es wdecay seed stop-epoch WETC TD NPMI@10% NPMI@20% NPMI@30% NPMI@40% NPMI@50% NPMI@60% NPMI@70% NPMI@80% NPMI@90% NPMI@100% Cv@10% Cv@20% Cv@30% Cv@40% Cv@50% Cv@60% Cv@70% Cv@80% Cv@90% Cv@100% Cp@10% Cp@20% Cp@30% Cp@40% Cp@50% Cp@60% Cp@70% Cp@80% Cp@90% Cp@100%".split()
    writer = SafeCSVWriter("training_metrics1.csv", columns)
    # Build topic model
    tmodel = TopicModel(n_topics=args.topics,
        vocabulary_size=vocabulary_size,
        n_hidden=args.n_hidden,
        topk=args.topk,
        embedding_size=100,
        id2word=id2word,
        enc_lr=args.enc_lr,
        dec_lr=args.dec_lr,
        tc=tc,
        measure=args.measure.split(','),
        c_device=device,
        wdecay=args.wdecay,
        enc_plm_path=enc_plm_path,
        dec_plm_path=dec_plm_path,
        nobetaembedding=args.nobetaembedding,
        wordembedding_mat=wordembedding_mat,
        cycle_annealing=ca,
        mlm_weight=args.mlmweight,
        rec_weight=args.recweight,
        mlm_prob=args.mlmprob,
        run_id={"str":run_id_str, "dict":run_id},
        time_str=time_formatted_now,
        csv_writer=writer,
        tau=args.tau,
        tb=args.tb,
        savckpt=args.savckpt,
        theta_actf=args.theta_actf,
        disable_automatic_optimize=True)
    #model=model.to(device)
    #Train & test process
    scheduler = TauScheduler(initial_value=args.tau, final_value=args.ftv, total_steps=args.tsteps)
    callback_list.append(scheduler)
    print("Initializing training procedure... ...")
    print("===========================================================================================================")
    trainer = pl.Trainer(accelerator='gpu', 
                        max_epochs=args.max_epochs,
                        callbacks=callback_list,
                        log_every_n_steps=10,
                        logger=None if not args.tb else logger,
                        enable_progress_bar=args.bg,
                        enable_model_summary=args.bg,
                        enable_checkpointing=True if args.savckpt else False,
                        devices=1)
    trainer.fit(model = tmodel, 
                train_dataloaders = train_dataloader,
                val_dataloaders = validation_dataloader)
    trainer.test(model = tmodel,
                dataloaders = test_dataloader)

if __name__ == '__main__':
    main()
