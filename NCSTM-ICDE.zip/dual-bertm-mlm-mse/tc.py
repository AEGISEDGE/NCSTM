# -*- coding: utf-8 -*-
import argparse, sys, os
import numpy as np
import pickle

from palmettopy.palmetto import Palmetto

#==================================================================================================================
# Function for automatic topic coherence calculation
# Run Palmetto_config to get Palmetto object, 
# then pass topic word list, Palmetto object and coherence measure to Get_topic_coherence for coherence score

class TopicCoherence(object):
    def __init__(self, server_url, timeout=10) -> None:
        if server_url==None:
            self.model = Palmetto("http://localhost:7777/service/", timeout=timeout)
        else:
            self.model = Palmetto(str(server_url))
    
    def Get_batch_topic_coherence(self, topic_word_lists, measure):
        score = []
        for topic in topic_word_lists:
            score.append( self.Get_topic_coherence(topic, measure) )
        return np.mean(score)

    def Get_topic_coherence(self, topic_word_lists, measure):
        if measure in ["ca", "cp", "npmi", "uci", "umass"]:
            # Get desired metric score
            return self.model.get_coherence(topic_word_lists, coherence_type=measure)
        else:
            return self.model.get_coherence(topic_word_lists, coherence_type="npmi")

    def Show_topic_coherence(self, topic_words_list, measure):
        # Call Palmetto_config first
        # Measure can be chosen from "ca", "cp", "npmi", "uci", and "umass"
        # npmi
        print("====================================")
        if measure in ["ca", "cp", "npmi", "uci", "umass"]:
            # Get desired metric score
            print("Topic coherence %s : %.6f " % (measure, self.Get_batch_topic_coherence(topic_words_list, coherence_type=measure) ) )
        elif measure=="ALL":
            # Get all metrics score
            for ct in ["ca", "cp", "npmi", "uci", "umass"]:
                print("Topic coherence %s : %.6f " % (ct, self.Get_batch_topic_coherence( topic_words_list, ct) ) )
        else:
            # Default NPMI score
            print("Topic coherence %s : %.6f " % ("npmi", self.Get_batch_topic_coherence(topic_words_list, coherence_type="npmi") ) )
        print("====================================")
