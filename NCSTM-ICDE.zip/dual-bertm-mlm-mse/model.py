# -*- coding: utf-8 -*-
import torch, copy, pickle, sys, os, time, transformers
import torch.utils.data
import pytorch_lightning as pl
import numpy as np
import torch.nn.functional as F

from tqdm import tqdm, trange
from pytorch_lightning.callbacks.early_stopping import EarlyStopping
from palmettopy.palmetto import Palmetto
from torch import nn, optim
from torch.nn.parameter import Parameter
from sparsemax import Sparsemax

# import symbolic constant

# from utils import Abnormal_value, MODEL_SAV_PATH, MAX_TO_KEEP

# from geomloss import SamplesLoss
from transformers import AutoTokenizer, AutoModel, AutoModelForMaskedLM

# from torch.distributions.exponential import Exponential
from torch.distributions.gamma import Gamma
# from torch.distributions.gumbel import Gumbel
from torch.distributions.normal import Normal
from torch.distributions.log_normal import LogNormal

# from torch.distributions.kl import kl_divergence

#====================================================================================================================================================
# Model definition
#----------------------------------------------------------------------------------------------------------------------------------------------------
class Encoder(pl.LightningModule):
    def __init__(self, 
        n_topics,
        vocabulary_size,
        plm_path,
        n_hidden,
        c_device,
        disable_automatic_optimize=False):
        #
        super(Encoder, self).__init__()
        self.topics = n_topics
        self.n_topics = n_topics
        self.vocabulary_size = vocabulary_size
        self.c_device = c_device
        self.plm_tokenizer = AutoTokenizer.from_pretrained(plm_path)
        self.plm = AutoModel.from_pretrained(plm_path)
        self.n_head = self.plm.config.num_attention_heads 
        self.plm_hidden = self.plm.config.hidden_size
        plm_hidden = self.plm_hidden
        #
        mlp_linear = nn.Linear(plm_hidden, n_hidden)
        torch.nn.init.xavier_uniform_( mlp_linear.weight, gain=1.0 )
        self.mlp = nn.Sequential(
            mlp_linear,
            nn.Softplus(),
        )
        # linear,bn layer for loc, logscale
        self.bn = nn.BatchNorm1d( n_topics, affine=False )
        # loc
        self.loc = nn.Linear( n_hidden, n_topics )
        # self.loc = nn.Linear( plm_hidden, n_topics )
        self.lbn = nn.BatchNorm1d( n_topics, affine=False )
        self.sbn = nn.BatchNorm1d( n_topics, affine=False )
        torch.nn.init.xavier_uniform_( self.loc.weight, gain=1.0 )
        # logscale
        self.logscale = nn.Linear( n_hidden, n_topics )
        # self.logscale = nn.Linear( plm_hidden, n_topics )
        self.sbn = nn.BatchNorm1d( n_topics, affine=False )
        self.logscale.weight.data.fill_(0.0)
        self.logscale.bias.data.fill_(0.0) 
        self.softplus = nn.Softplus()
        self.relu = nn.ReLU()
        if disable_automatic_optimize:
            self.automatic_optimization = False
        self.save_hyperparameters()

    # KL divergence for dual isotropic Normal or Log Normal
    def KL_Gaussian(self, mu, logsigma):
        return -0.5 * torch.sum(1 - torch.pow(mu ,2) + 2 * logsigma - torch.exp(2*logsigma), 1)
    
    def KL_LA(self, loc, logscale):
        # Standard N(0, I) prior
        prior_mean = torch.zeros_like(loc).to(self.c_device)
        prior_var = torch.ones_like(logscale).to(self.c_device)
        prior_logvar = torch.log(prior_var)
        # 
        var_division = torch.sum( torch.exp(logscale) / prior_var, dim=1)
        diff_means = loc - prior_mean
        diff_term = torch.sum( (diff_means * diff_means) / prior_var, dim=1)
        logvar_det_division = prior_logvar.sum() - logscale.sum(dim=1)
        #
        return 0.5 * ( var_division + diff_term + logvar_det_division - self.n_topics )

    def Wasserstein_Lognormal(self, mu, logsigma):
        sigma_sq = torch.exp(2 * logsigma)
        
        # 计算每个项的贡献
        term1 = torch.exp(2 * mu + 2 * sigma_sq)
        term2 = -2 * torch.exp(mu + (sigma_sq + 1) / 2)
        term3 = torch.exp(torch.tensor(2.0, device=mu.device))
        
        # 每个元素的Wasserstein距离平方
        wasserstein_sq_per_element = term1 + term2 + term3
        
        # 求和得到总平方距离
        total_wasserstein_sq = torch.sum(wasserstein_sq_per_element)
        
        # 计算Wasserstein距离
        wasserstein_distance = torch.sqrt(total_wasserstein_sq)
        
        return wasserstein_distance

    # Normalize sparse BOW vectors into multinomial sparse vectors
    def doc_norm(self, doc_bow):
        return ( doc_bow.t() / doc_bow.sum(1) ).t()
    
    def Mean_pooling(self, model_output, attention_mask):
        token_embeddings = model_output[0] #First element of model_output contains all token embeddings
        input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

    def forward(self, rawtxt):
        with torch.no_grad(): #max_length=512, padding=True, truncation=True
            # max_length = max([len(s) for s in rawtxt]) ## min([max_length, 512])
            encoded_input = self.plm_tokenizer(rawtxt, return_tensors='pt', max_length=512, padding=True, truncation=True).to(self.c_device)
            # cvec = self.plm(**encoded_input)[0].mean(dim=1) # [batch_size, plm_hidden]
            outputs = self.plm(**encoded_input)
            cvec = self.plm(**encoded_input)[0].mean(dim=1) # [batch_size, plm_hidden]
        # print(outputs[0].shape)
        # cvec = self.Mean_pooling( outputs[0], encoded_input['attention_mask'] ) #
        # print(cvec.size())
        # h_vec = input_vec
        h_vec = self.mlp(cvec)
        loc = self.lbn( self.loc( h_vec ) )
        logscale = self.sbn( self.logscale(h_vec) )
        # return loc, logscale, self.KL_Gaussian(loc, logscale)
        return loc, logscale, self.KL_LA(loc, logscale), cvec
        # return loc, logscale, self.Wasserstein_Lognormal(loc, logscale), cvec

#---------------------------------------------------------------------------------------------------------------------------------------------------
class Decoder(pl.LightningModule):
    def __init__(self, 
        vocabulary_size, 
        n_topics, 
        c_device,
        embedding_size,
        id2word,
        plm_path,
        gamma=0.1,
        mlm_prob=0.15,
        topk=10,
        theta_actf="softmax",
        wordembedding_mat=None,
        disable_automatic_optimize=False):
        super(Decoder, self).__init__()
        # Record model paramters
        self.topk = topk
        self.c_device = c_device
        self.n_topics = n_topics
        self.vocabulary_size = vocabulary_size
        self.embedding_size = embedding_size
        self.id2word = id2word
        self.mlm_prob=mlm_prob
        self.gamma=nn.Parameter(torch.Tensor([gamma]).to(self.c_device))
        self.cbeta=None
        # 
        self.theta_softmax=nn.Softmax(dim=-1)
        self.bn = nn.BatchNorm1d(vocabulary_size, affine=False)
        # load AutoModelForMaskedLM and tokenizer
        self.plm_tokenizer = AutoTokenizer.from_pretrained(plm_path)
        self.plm = AutoModelForMaskedLM.from_pretrained(plm_path)
        self.plm.to(self.c_device)
        self.n_head = self.plm.config.num_attention_heads 
        self.plm_hidden = self.plm.config.hidden_size
        plm_hidden = self.plm_hidden
        self.mask_token_id = self.plm_tokenizer.mask_token_id
        self.vocab = self.plm_tokenizer.get_vocab()
        # # Topic embedding def
        topic_embedding_mat = torch.nn.init.orthogonal_(torch.Tensor(n_topics, embedding_size)).to(self.c_device)
        self.topic_embedding_mat = torch.nn.Parameter(topic_embedding_mat)
        # self.register_parameter( 'topic_embedding_mat', Parameter(topic_embedding_mat))
        # self.register_parameter('topic_embedding_mat', Parameter(topic_embedding_mat))
        # Word embedding def
        if wordembedding_mat==None:
            word_embedding_mat = torch.Tensor(embedding_size, vocabulary_size).to(self.c_device)
            torch.nn.init.orthogonal_(word_embedding_mat.data, gain=1.0)
            self.word_embedding_mat = torch.nn.Parameter(word_embedding_mat) 
            # torch.nn.init.normal_(word_embedding_mat)
            # torch.nn.init.xavier_uniform_( word_embedding_mat, gain=1.0 )
            # self.register_parameter('word_embedding_mat', Parameter(word_embedding_mat) )
        else:
            word_embedding_mat = torch.Tensor(wordembedding_mat).to(self.c_device).t()
            word_embedding_mat.requires_grad = False
            self.word_embedding_mat = word_embedding_mat
        # ----------------------------------------------------------------------------
        # self.beta_linear = nn.Sequential(
        #     nn.Linear(embedding_size, int(0.5 * vocabulary_size), bias=False),
        #     nn.ReLU(),
        #     nn.Linear(int(0.5 * vocabulary_size), vocabulary_size, bias=False),
        #     nn.Softplus(),
        #     nn.Dropout(dropout_prob)
        # )
        # topicvec_mat = torch.Tensor(n_topics, vocabulary_size)
        # topicvec_mat = torch.Tensor( vocabulary_size, n_topics )
        # torch.nn.init.orthogonal_(topicvec_mat) # Orthogonal initialization 
        # self.register_parameter('topicvec_mat', Parameter(topicvec_mat.t()) )
        # self.topicmat_linear = nn.Sequential(
        #     nn.Linear(vocabulary_size, vocabulary_size),
        #     nn.Dropout(dropout_prob),
        #     nn.Softmax(-1)
        # )
        # Topic embeddings
        self.softmax = nn.Softmax(-1)
        self.sparsemax = Sparsemax(-1)
        self.logsoftmax = nn.LogSoftmax(-1)
        self.softplus = nn.Softplus()
        self.sigmoid = nn.Sigmoid()
        self.relu = nn.ReLU()
        if theta_actf == "softmax":
            self.theta_actf = nn.Softmax(-1)
        elif theta_actf == "sparsemax":
            self.theta_actf = Sparsemax(-1)
        elif theta_actf == "softplus":
            self.theta_actf = nn.Softplus(-1)
        elif theta_actf == 'None':
            self.theta_actf = nn.Identity()
        # self.adaptor = nn.Sequential(
        #     nn.Linear(plm_hidden, vocabulary_size, bias=False),
        #     # nn.Linear(dn_hidden, vocabulary_size),
        #     # nn.Tanh(),
        #     # nn.BatchNorm1d(vocabulary_size, affine=False),
        #     nn.Softplus()
        #     # nn.Dropout(dropout_prob)
        # )
        #
        # eta_weight = 0.5 * torch.ones(n_topics, 1)
        if disable_automatic_optimize:
            self.automatic_optimization = False
        self.save_hyperparameters()

    def Top_k_value_filter_norm(self, input_mat, k=10):
        # Get top-k topic word distribution probability sparse matrix hv vbbc
        vec_length = len(input_mat)
        topk = input_mat.topk(dim=-1, k=k)
        vec_list=[]
        for i in range(vec_length):
            filtered_vec = torch.sparse_coo_tensor(topk.indices[i].unsqueeze(0), topk.values[i], [self.vocabulary_size], requires_grad=True).to_dense()
            vec_list.append(filtered_vec / filtered_vec.sum(-1))
        return torch.stack(vec_list) # beta_mat like sparse tensor

    def STL_with_topictxtprob(self, input_mat, id2word, k, training, tau=0.5):
        topic_txt_list = []
        topic_prob_list= []
        # Get top-k topic word distribution probability sparse matrix
        vec_length = len(input_mat)
        # if training：
        topic_prob_value, topic_indice = self.Gumbel_topk(input_mat, k=k, tau=tau, training=training)
        # else:
        #     topk = input_mat.topk(dim=-1, k=k)
        #     topic_prob_value = topk[0] # value
        #     topic_indice = topk[1] # indice    
        for topic in range(len(topic_indice)):
            topic_txt_list.append(" ".join([id2word[int(x)] for x in topic_indice[topic]]))
            topic_prob_list.append(topic_prob_value[topic])
        vec_list=[]
        for i in range(vec_length):
            # filtered_vec = torch.sparse_coo_tensor(topk.indices[i].unsqueeze(0), topk.values[i], [self.vocabulary_size], requires_grad=True).to_dense()
            filtered_vec = torch.sparse_coo_tensor(topic_indice[i].unsqueeze(0), topic_prob_value[i], [self.vocabulary_size], requires_grad=True).to_dense()
            vec_list.append(filtered_vec / filtered_vec.sum(-1)) # Normalize into multinomial vector
            # vec_list.append( filtered_vec ) 
        return torch.stack(vec_list), topic_txt_list, topic_prob_list # beta_mat like sparse tensor, raw topic top-k word txt list, corresponding topic word probability(weight): tensor() object

    def Gumbel_topk(self, input_mat, k, tau=1.0, training=True, dim=-1):
        if training:
            # 生成Gumbel噪声
            gumbel_noise = -torch.empty_like(input_mat).exponential_().log()  # Gumbel(0,1)
            perturbed = input_mat + gumbel_noise
        else:
            perturbed = input_mat  # 测试时直接使用原始值

        # 应用温度缩放
        perturbed = perturbed / tau
        
        # 获取topk的索引
        topk_values, topic_indice = torch.topk(perturbed, k=k, dim=dim)
        
        # 创建硬掩码以选择topk元素
        mask = torch.zeros_like(input_mat, dtype=torch.float).scatter_(dim, topic_indice, 1.0)
        
        if training:
            # 计算softmax用于梯度近似
            soft_mask = F.softmax(perturbed, dim=dim)
            # 直通估计器：前向用硬掩码，反向用softmax的梯度
            mask = mask + (soft_mask - soft_mask.detach())
        
        # 收集原始input_mat中对应位置的值
        topic_prob_value = torch.gather(input_mat, dim, topic_indice)
        
        return topic_prob_value, topic_indice

    def Mean_pooling(self, model_output, attention_mask):
        token_embeddings = model_output[0] #First element of model_output contains all token embeddings
        input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

    def sum_norm(self, vec):
        return vec / vec.sum(0).t()
    
    def Get_topic_dist(self):
        with torch.no_grad():
            return self.Get_beta().detach()
            # return self.softmax(self.topicvec_mat)
            # return self.softmax( torch.mm(self.topic_embedding_mat, self.word_embedding_mat) )
    
    def Get_beta(self):
        # gamma = self.sigmoid(self.gamma)
        # if self.cbeta != None:
        #     self.beta = self.softmax( (1.0- gamma) * torch.mm(self.topic_embedding_mat, self.word_embedding_mat) + gamma * self.cbeta )
        # else:
        #     self.beta = self.softmax(torch.mm(self.topic_embedding_mat, self.word_embedding_mat))
        self.beta = self.softmax(torch.mm(self.topic_embedding_mat, self.word_embedding_mat))
        # self.beta = self.beta_linear(self.topic_embedding_mat)
        return self.beta # [n_topics, vocabulary]

    def Gaussian_Reparameterization(self, mu, logsigma):
        std = torch.exp(logsigma)
        eps= torch.normal(mean = torch.zeros(mu.shape[1])).to(self.c_device)
        return torch.mul(eps, std).add_(mu)

    def LogNormal_Reparameterization(self, mu, logsigma):
        std = torch.exp(logsigma)
        eps= torch.normal(mean = torch.zeros(mu.shape[1])).to(self.c_device)
        return torch.exp(torch.mul(eps, std).add_(mu))

    def mask_tokens(self, token_ids):
        """
        对输入序列进行随机遮蔽
        Args:
            token_ids: 原始token id序列 (batch, seq_len)
        Returns:
            masked_tokens: 遮蔽后的序列
            labels: 被遮蔽位置的原始标签（未遮蔽位置为-100）
        """
        labels = token_ids.clone()
        # 创建遮蔽矩阵
        prob_matrix = torch.full(labels.shape, self.mlm_prob)
        masked_indices = torch.bernoulli(prob_matrix).bool()
        
        # 80%概率替换为[MASK]
        indices_replaced = masked_indices & (torch.rand(labels.shape) < 0.8)
        token_ids[indices_replaced] = self.mask_token_id
        
        # 10%概率替换为随机词
        indices_random = masked_indices & (torch.rand(labels.shape) < 0.5)
        random_words = torch.randint(len(self.vocab), labels.shape).to(self.c_device)
        token_ids[indices_random] = random_words[indices_random]
        
        # 剩余10%保持原词
        labels[~masked_indices] = -100  # 忽略未遮蔽位置
        
        return token_ids, labels

    # Working flow of generative model
    def forward(self, loc, logscale, doc_bow, cvec, training, tau=0.5):
        # Document topic proportion Normal sample vector
        # -------------Gaussian RT
        # Log Normal RT
        # theta = self.LogNormal_Reparameterization(loc, logscale)
        doc_code = self.Gaussian_Reparameterization(loc, logscale)
        # n_theta = self.dropout( self.softmax(theta) ) #[batch_size, n_topics]
        # -------------Log normal RT
        # theta = self.LogNormal_Reparameterization(loc, logscale)
        # n_theta = self.dropout( self.softmax(theta) ) #[batch_size, n_topics] # ***PREVIOUS BEST OPTION***
        n_theta = self.theta_actf(doc_code)
        # if self.theta_actf == 'no':
        #     n_theta = doc_code
        # elif self.theta_actf == 'sparsemax':
        #     n_theta = self.sparsemax(doc_code)
        # elif self.theta_actf == 'softplus':
        #     n_theta = self.softplus(doc_code)
        # else:
        #     n_theta = self.softmax(doc_code) #[batch_size, n_topics]
        # n_theta = self.dropout( self.sparsemax(theta) ) #[batch_size, n_topics]
        # Normalized Document topic proportion vector
        # topic_dist = self.Get_topicvec_mat()
        # topic_mat = self.topicvec_mat
        # Topic word distribution mat beta
        # self.beta = self.softmax( torch.mm(self.topic_embedding_mat, self.word_embedding_mat) )
        filtered_topic_mat, topic_topk_words, topic_topk_prob = self.STL_with_topictxtprob( self.Get_beta(), self.id2word, self.topk , training, tau=tau)
        encoded_input = self.plm_tokenizer(topic_topk_words, return_tensors='pt', max_length=self.topk, padding=True, truncation=True, add_special_tokens=False).to(self.c_device)
        input_ids, label = self.mask_tokens(encoded_input['input_ids'])
        outputs = self.plm(input_ids, attention_mask=encoded_input['attention_mask'], output_hidden_states=True, labels=label)
        mlm_loss = outputs.loss.mean(-1) # [batch, n_topics]
        d_cvec = outputs.hidden_states[-1] # [n_topics, topk, plm_hidden]
        tc_vec = torch.einsum("kl,klh->kh", torch.stack(topic_topk_prob), d_cvec) #[n_topics, plm_hidden]
        rec_vec = torch.einsum("bk,kh->bh", n_theta, tc_vec)
        #==============================================================================
        # tc_vec = torch.bmm( torch.stack( topic_topk_prob ).unsqueeze(1), d_cvec ).squeeze() # [n_topics, plm_hidden]
        # self.cbeta = self.adaptor(tc_vec) # [n_topics, vocab_size]
        # sbeta = self.Get_beta()
        # gamma = self.sigmoid(self.gamma)
        # beta = self.softmax( (1.0- gamma) * sbeta + gamma * self.cbeta )
        # NLL Loss over BOW representation
        # logits = self.logsoftmax( self.bn( torch.matmul(n_theta, beta) ) + 1e-10 )
        # recon_loss = -torch.sum(torch.mul(logits, doc_bow), -1) + mlm_loss
        #==============================================================================
        mse_loss = F.mse_loss(rec_vec, cvec.detach())
        loss = {
            'mse': mse_loss,
            'mlm': mlm_loss
        }
        #==============================================================================
        # =========================================================================================
        # Vannila BERT Transformer interface
        # with torch.no_grad(): #max_length=512, padding=True, truncation=True
        #     # encoded_input = self.plm_tokenizer(topic_topk_words, return_tensors='pt', max_length=self.topk, padding=True, truncation=True, add_special_tokens=False).to(self.c_device)
        #     encoded_input = self.plm_tokenizer(topic_topk_words, 
        #                                         return_tensors='pt', 
        #                                         max_length=self.topk, 
        #                                         padding=True, 
        #                                         truncation=True, 
        #                                         add_special_tokens=False).to(self.c_device)
        #     d_cvec = self.plm( **encoded_input )[0]   # [n_topics, topk, plm_hidden]
        # Fusion between semantic features and corresponding probability
        # tc_vec = torch.bmm( torch.stack( topic_topk_prob ).unsqueeze(1), d_cvec ).squeeze() # [n_topics, plm_hidden]
        # logits = self.logsoftmax( self.bn( torch.matmul(n_theta, self.adaptor(tc_vec)) ) + 1e-10 )
        # recon_loss = -torch.sum(torch.mul(logits, doc_bow), -1)
        # =========================================================================================

        # adaptor_output = self.adaptor(tc_vec)
        # self.eta = self.sigmoid( self.etaweight )
        # beta = self.eta * filtered_topic_mat + (1.0 - self.eta) * adaptor_output
        #----------------------------------------------------------------------------------------
        # logits = self.logsoftmax( self.bn( torch.matmul(n_theta, self.beta) ) + 1e-10 )
        # logits = self.logsoftmax( self.bn( torch.matmul(n_theta, beta) ) + 1e-10 )
        # logits = self.logsoftmax( self.bn( self.adaptor( torch.matmul(n_theta, tc_vec) ) ) + 1e-10 )
        # ---------------------------------------------------------------------------------------
        # GSM-BASE loss
        # topic_dist = self.Get_topic_dist()
        # logits = self.logsoftmax( self.bn( torch.matmul(n_theta, topic_dist) ) + 1e-10 )
        #----------------------------------------------------------------------------------------
        return loss, n_theta, doc_code

#====================================================================================================================================================
class NSCTM(pl.LightningModule):
    def __init__(self, 
        n_topics,
        vocabulary_size,
        n_hidden,
        embedding_size,
        id2word,
        enc_lr,
        dec_lr,
        c_device,
        enc_plm_path,
        dec_plm_path,
        tc,
        tb,
        cycle_annealing,
        run_id,
        tau,
        csv_writer,
        time_str,
        wdecay,
        theta_actf,
        nobetaembedding,
        savckpt=False,
        mlm_weight=1.0,
        rec_weight=1.0,
        mlm_prob=0.15,
        measure='npmi,cp'.split(','),
        topk=10,
        wordembedding_mat=None,
        disable_automatic_optimize=False):
        super(NSCTM, self).__init__()
        self.c_device = c_device
        self.n_topics = n_topics
        self.vocabulary_size = vocabulary_size
        self.enc_lr = enc_lr
        self.dec_lr = dec_lr
        self.topk = topk
        self.tc = tc
        self.tb = tb
        self.measure = measure
        self.wdecay=wdecay
        self.ca = cycle_annealing.Get_weight()
        self.cycle_annealing_weight = 0.0
        self.run_id=run_id["str"]
        self.run_id_dict=run_id["dict"]
        self.tau=tau
        self.csv_writer=csv_writer
        self.time_str=time_str
        self.mlm_weight=mlm_weight
        self.rec_weight=rec_weight
        self.savckpt = savckpt
        self.nobetaembedding = nobetaembedding
        self.tb = tb
        # 
        if disable_automatic_optimize:
            self.automatic_optimization = False
        # Encoder
        self.encoder = Encoder(n_topics=self.n_topics,
                               vocabulary_size=vocabulary_size,
                               n_hidden=n_hidden,
                               plm_path=enc_plm_path,
                               c_device=c_device)
        self.wordembedding_mat = torch.Tensor(wordembedding_mat).to(c_device)
        # Decoder
        self.decoder = Decoder(n_topics=n_topics,
                               vocabulary_size=vocabulary_size,
                               topk=topk,
                               plm_path=dec_plm_path,
                               embedding_size=embedding_size,
                               wordembedding_mat=None if nobetaembedding else self.wordembedding_mat,
                               mlm_prob=mlm_prob,
                               id2word=id2word,
                               theta_actf=theta_actf,
                               c_device=c_device)
        self.save_hyperparameters()
    
    def Get_topicword_txt_matrices(self, k=None):
        if k==None:
            k = self.topk
        # _, topicword_txt,_ = self.decoder.STL_with_topictxtprob(self.decoder.Get_topic_dist(), self.decoder.id2word, topk, training=False)
        id2word = self.decoder.id2word
        input_mat = self.decoder.Get_topic_dist()
        topic_txt_list = []
        topic_prob_list= []
        # Get top-k topic word distribution probability sparse matrix
        vec_length = len(input_mat)
        topk = input_mat.topk(dim=-1, k=k)
        topic_prob_value = topk[0] # value
        topic_indice = topk[1] # indice    
        for topic in range(len(topic_indice)):
            topic_txt_list.append(" ".join([id2word[int(x)] for x in topic_indice[topic]]))
            topic_prob_list.append(topic_prob_value[topic])
        vec_list=[]
        for i in range(vec_length):
            # filtered_vec = torch.sparse_coo_tensor(topk.indices[i].unsqueeze(0), topk.values[i], [self.vocabulary_size], requires_grad=True).to_dense()
            filtered_vec = torch.sparse_coo_tensor(topic_indice[i].unsqueeze(0), topic_prob_value[i], [self.vocabulary_size], requires_grad=False).to_dense()
            vec_list.append(filtered_vec / filtered_vec.sum(-1)) # Normalize into multinomial vector
            # vec_list.append( filtered_vec ) 
        # return torch.stack(vec_list), topic_txt_list, topic_prob_list # beta_mat like sparse tensor, raw topic top-k word txt list, corresponding topic word probability(weight): tensor() object
        return topic_txt_list

    def Get_topic_dist(self):
        return self.decoder.Get_topic_dist()

    def forward(self, rawtxt, doc_bow, tau=0.5):
        loc, logscale, kl, cvec = self.encoder(rawtxt)
        training = self.trainer.training
        loss, theta, doc_code = self.decoder(loc, logscale, doc_bow, cvec, training, self.tau)
        loss['kl'] = kl
        loss['weighted'] = self.rec_weight * loss['mse'] + self.mlm_weight * loss['mlm']
        return loss, theta, doc_code
#---------------------------------------------------------------------------------------------
    # def configure_optimizers(self):
    #     self.optim=optim.Adam(self.parameters(), lr=self.learning_rate)
    #     return self.optim

    def configure_optimizers(self):
        #-------------------------------------------------------------------------------------
        # Adam optimizer:
        # self.enc_optim=AdamW(self.encoder.parameters(),
        #     lr=self.enc_lr,
        #     eps=1e-6,
        #     weight_decay=self.wdecay,
        #     correct_bias=True)
        # no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
        # self.dec_optim=AdamW([
        #         {'params': self.decoder.topic_embedding_mat},
        #         {'params': [p for n,p in self.decoder.plm.named_parameters() if not any(nd in n for nd in no_decay)], 'weight_decay': self.wdecay},
        #         {'params': [p for n,p in self.decoder.plm.named_parameters() if any(nd in n for nd in no_decay)], 'weight_decay': 0.0},
        #     ], 
        #     lr=self.dec_lr,
        #     eps=1e-6,
        #     weight_decay=self.wdecay,
        #     correct_bias=True)
        #-------------------------------------------------------------------------------------
        self.enc_optim=optim.Adam(self.encoder.parameters(), lr=self.enc_lr)
        # if self.nobetaembedding:
        #     decoder_params = [
        #         {"params": [self.decoder.topic_embedding_mat] , "lr": self.dec_lr},
        #         {"params": self.decoder.plm.parameters(), "lr": 0.1 * self.dec_lr}
        #     ]
        # else:
        #     decoder_params = [
        #         {"params": [self.decoder.topic_embedding_mat, self.decoder.word_embedding_mat] , "lr": self.dec_lr},
        #         {"params": self.decoder.plm.parameters(), "lr": 0.1 * self.dec_lr}
        #     ]
        # decoder_params = [
        #         {"params": [self.decoder.topic_embedding_mat, self.decoder.word_embedding_mat] , "lr": self.dec_lr},
        #         {"params": self.decoder.plm.parameters(), "lr": self.dec_lr}
        # ]
        # self.dec_optim=optim.Adam(decoder_params)
        self.dec_optim=optim.Adam(self.decoder.parameters(), lr=self.dec_lr)
        # SGD with momentum
        # momentum=0.5
        # self.enc_optim=optim.SGD( self.encoder.parameters(), lr=self.learning_rate, momentum=momentum )
        # self.dec_optim=optim.SGD( self.decoder.parameters(), lr=self.learning_rate, momentum=momentum )
        #-------------------------------------------------------------------------------------
        return [self.enc_optim, self.dec_optim]
#---------------------------------------------------------------------------------------------
    def compute_corpus_step(self, batch):
        # rawtxt, doc_bow, word_cnt, label = batch # batch data input
        rawtxt, doc_bow, word_cnt = batch
        loss, theta, doc_code = self( rawtxt, doc_bow.to(self.c_device)) # [batch_size,1] ; [batch_size, n_topics]
        # loss = recon_loss + kl
        # model_loss = loss['weighted'] + next(self.ca_weight) * loss['kl']
        model_loss = loss['weighted']
        return {"loss": model_loss.mean(),
                "loss_batch": model_loss,
                "recon_loss": loss['mse'],
                "kld": loss['kl'],
                "theta": theta,
                "word_cnt": word_cnt}      
    
    def compute_corpus_epoch_end(self, output, phase_name, enable_log=False):
        loss_sum = 0.0 
        ppx_sum = 0.0
        kl_sum = 0.0
        corpus_word_count = 0
        doc_cnt = 0
        epoch = self.current_epoch
        for batch_statics in output:
            # TODO: Finalize PPL KL computation
            loss, loss_batch, recon_loss, kl, theta, word_cnt = batch_statics.values()
            loss_sum += loss
            kl_sum += kl.sum()
            ppx_sum += torch.sum( loss_batch / word_cnt )
            corpus_word_count += torch.sum(word_cnt)
            doc_cnt += len(word_cnt)
        # Logging metrics
        if phase_name != "test " and enable_log:
            self.log(phase_name + "_loss", loss_sum / doc_cnt, on_epoch=True, logger=self.tb)
            self.log(phase_name + " PPL", torch.exp(loss_sum / corpus_word_count), on_epoch=True, logger=self.tb)
            self.log(phase_name + " KLD", kl_sum/doc_cnt, on_epoch=True, logger=self.tb)
            self.log(phase_name + " per doc PPL", torch.exp(ppx_sum / doc_cnt), on_epoch=True, logger=self.tb)

    # Manual optimization
    def training_step(self, batch, batch_idx):
        # return self.compute_corpus_step(batch)
        # epoch = self.current_epoch
        epoch = batch_idx
        if epoch %2 ==0:
            phase = "Encoder"
            opt = self.optimizers()[0]
        elif epoch %2 ==1:
            phase = "Decoder"
            opt = self.optimizers()[1]
        opt.zero_grad()
        # rawtxt, doc_bow, word_cnt, label = batch # batch data input
        rawtxt, doc_bow, word_cnt = batch
        # recon_loss, kl, theta = self( rawtxt, doc_bow.to(self.c_device), self.tau) # [batch_size,1] ; [batch_size, n_topics]
        loss, theta, doc_code = self( rawtxt, doc_bow.to(self.c_device), self.tau) # [batch_size,1] ; [batch_size, n_topics]
        # loss = recon_loss + kl
        # loss = recon_loss + self.cycle_annealing_weight * kl
        # loss = recon_loss + next(self.ca) * kl
        # model_loss = loss['weighted'] + next(self.ca) * loss['kl']
        model_loss = loss['weighted'] + next(self.ca) * loss['kl']
        loss_mean = model_loss.mean()
        nelbo = loss['mse'] + loss['kl']
        nelbo_mean = nelbo.mean()
        self.manual_backward(loss_mean)
        # self.manual_backward(loss_mean,retain_graph=True)
        opt.step()
        # self.log("step loss", loss_mean, on_step=True, prog_bar=True)
        return {"loss": loss_mean,
                "loss_batch": model_loss,
                "nelbo": nelbo,
                "nelbo_mean": nelbo_mean,
                "recon_loss": loss['mse'],
                "kl": loss['kl'],
                "theta": theta,
                "word_cnt_sum": word_cnt}

    # def training_step(self, batch, batch_idx):
    #     # return self.compute_corpus_step(batch)
    #     # epoch = self.current_epoch
    #     rawtxt, doc_bow, word_cnt, label = batch # batch data input
    #     recon_loss, kl, theta = self( rawtxt, doc_bow.to(self.c_device) ) # [batch_size,1] ; [batch_size, n_topics]
    #     loss = recon_loss + kl
    #     loss_mean = loss.mean()
    #     self.log("step loss", loss_mean, on_step=True, prog_bar=True)
    #     return {"loss": loss_mean,
    #             "loss_batch": loss,
    #             "recon_loss": recon_loss,
    #             "kl": kl,
    #             "theta": theta,
    #             "word_cnt_sum": word_cnt}    
    
    def training_epoch_end(self, training_step_output):
        # Variables for training epoch
        loss_sum = 0.0 
        ppx_sum = 0.0
        kl_sum = 0.0
        corpus_word_count = 0
        doc_cnt = 0
        epoch = self.current_epoch
        for batch_statics in training_step_output:
            # TODO: Finalize PPL KL computation
            loss, loss_batch, nelbo, nelbo_mean, recon_loss, kl, theta, word_cnt = batch_statics.values()
            loss_sum += nelbo_mean
            kl_sum += kl.sum()
            ppx_sum += torch.sum( loss_batch / word_cnt )
            corpus_word_count += torch.sum(word_cnt)
            doc_cnt += len(word_cnt)
        # Logging metrics
        self.log("training_loss", loss_sum / doc_cnt, on_epoch=True, logger=self.tb)
        self.log("training PPL", torch.exp(loss_sum / corpus_word_count), on_epoch=True, logger=self.tb)
        self.log("training KLD", kl_sum/doc_cnt, on_epoch=True, logger=self.tb)
        self.log("training per doc PPL", torch.exp(ppx_sum / doc_cnt), on_epoch=True, logger=self.tb)
        # Refresh cycle annealing weight at the end of each epoch
        # self.cycle_annealing_weight = next(self.ca)

#---------------------------------------------------------------------------------------------
    def validation_step(self, batch, batch_idx):
        return self.compute_corpus_step(batch)

    def validation_epoch_end(self, validation_step_output):
        loss_sum = 0.0 
        ppx_sum = 0.0
        kl_sum = 0.0
        corpus_word_count = 0
        doc_cnt = 0
        for batch_statics in validation_step_output:
            # TODO: Finalize PPL KL computation
            loss, loss_batch, recon_loss, kl, theta, word_cnt = batch_statics.values()
            loss_sum += loss
            # Add cycle annealing weighted loss as val loss source
            # loss_sum += (recon_loss + self.cycle_annealing_weight * kl).mean()
            kl_sum += kl.sum()
            ppx_sum += torch.sum( loss_batch / word_cnt )
            corpus_word_count += torch.sum(word_cnt)
            doc_cnt += len(word_cnt)
        # Logging metrics
        self.log("val_loss", loss_sum / doc_cnt, on_epoch=True, prog_bar=True, logger=self.tb)
        self.log("val PPL", torch.exp(loss_sum / corpus_word_count), on_epoch=True, logger=self.tb)
        self.log("val KLD", kl_sum/doc_cnt, on_epoch=True, logger=self.tb)
        self.log("val per doc PPL", torch.exp(ppx_sum / doc_cnt), on_epoch=True, logger=self.tb)

#---------------------------------------------------------------------------------------------
    def test_step(self, batch, batch_idx):
        return self.compute_corpus_step(batch)

    def test_epoch_end(self, test_step_output):
        # tc_avg = []
        tc_avg = {}
        result2csv = {
            "dataset":      self.run_id.split("_")[0],
            "time":         self.time_str,
            "topics":       self.run_id_dict["topics"],
            "hidden":       self.run_id_dict['h'],
            "cl":           self.run_id_dict['cl'],
            "cp":           self.run_id_dict['cp'],
            "mi":           self.run_id_dict['mi'],
            "plm-select":   self.run_id_dict["eplm-"],
            "wdecay":       self.run_id_dict["wdecay"],
            "topk":         self.run_id_dict["topk"],
            "tstep":         self.run_id_dict["tstep"],
            "tau":         self.run_id_dict["tau"],
            "ftv":         self.run_id_dict["ftv"],
            "bs":         self.run_id_dict["bs"],
            "mlmprob":     self.run_id_dict["mlmprob"],
            "mw":   self.run_id_dict["mw"],
            "rw":  self.run_id_dict["rw"],
            "p":     self.run_id_dict["p"],
            "es":   self.run_id_dict["es"],
            "elr":         self.run_id_dict["elr"],
            "elr":         self.run_id_dict["dlr"],
            "seed":         self.run_id_dict["seed"],
            "theta_actf":   self.run_id_dict["theta_actf"],
        }
        # Common model forward flow
        self.compute_corpus_epoch_end(test_step_output, "test ")
        # Task 1: Export global topics and compute topic coherence and topic diversity
        _, topic_word_list = self.compute_topic_diversity(10)
        td_score = self.get_topic_diversity(topic_word_list, 10)
        result2csv["TD"]=td_score
        # Word embedding topic coherence for given topic words
        wetc = self.WETC(self.Get_topic_dist(), self.wordembedding_mat)
        self.log("WETC: ", float(wetc))
        result2csv["WETC"] = float(wetc)
        if not os.path.exists("topic_files"):
            os.makedirs("topic_files")
        print("Calculating topic coherence:", end="")
        topic_id=0
        topic_with_tc = []
        filename = self.run_id + "_topic-" + str(self.current_epoch).zfill(3)
        with open(  "topic_files" + os.sep + filename + ".txt", 'w') as f:
            for line in tqdm(topic_word_list):
                tc_score_list = []
                for measure_opt in self.measure:
                    tc_score = self.tc.get_coherence(line.split(), measure_opt)
                    time.sleep(5)
                    if measure_opt in tc_avg.keys():
                        tc_avg[measure_opt].append(tc_score)
                    else:
                        tc_avg[measure_opt]=[tc_score]
                    tc_score_list.append(tc_score)
                #                      NPMI, C_P, topic_id, topic_word_list
                topic_with_tc.append( {'tc':tc_score_list, 'tid':topic_id, 'text':line} )
                topic_id += 1
            topic_with_tc.sort(key=lambda x: (sum(x['tc']))/len(x['tc']) , reverse=True)
            for topic_info in topic_with_tc:
                f.write( "Topic NO." + str(topic_info['tid']).zfill(3) + " | " + ', '.join(k + ':' +str(v) for k,v in zip(self.measure, topic_info['tc'])) + " | " + topic_info['text'] + os.linesep )
            # Top 10% step avg tc file write
            for k,v in tc_avg.items():
                v.sort(reverse=True)
            tc_top_dict = {} # key:measure + i*10% , value:top10%~100% mean values
            for i in range(1,11): # 
                f.write("Top " + str(i*10) + "%" + ",".join("avg " + k + ':' + str(np.mean(v[:int(self.n_topics * i / 10)])) for k,v in tc_avg.items()) + os.linesep )
                for k,v in tc_avg.items():
                    if k=='npmi':
                        pref="NPMI@"
                    elif k=="cv":
                        pref="Cv@"
                    elif k=="cp":
                        pref="Cp@"
                    tc_top_dict[pref+str(i*10)+"%"] = np.mean(v[:int(self.n_topics * i / 10)])
            result2csv.update(tc_top_dict)
            f.write("WETC: " + str(wetc) + os.linesep)
            f.write("TD: " + str(td_score) + os.linesep)
            ftc_score = ",".join("avg " + k + ' tc score :' + str(np.mean(v)) for k,v in tc_avg.items())
            f.write(ftc_score)
        result2csv["stop-epoch"] = self.current_epoch
        self.csv_writer.append_row(result2csv)
        self.log("avg topic diversity", td_score)
        for k,v in tc_avg.items():
            self.log("avg " + str(k) + " tc score: ", np.mean(v))
        if self.savckpt:
            if not os.path.exists("bin_topicstatics"):
                os.makedirs("bin_topicstatics")
            # Save topic statics
            pickle.dump(tc_avg, open("bin_topicstatics" + os.sep + filename + '.bin', 'wb'))

    def export_topic_word_topk_words(self, topk):
        return self.Get_topicword_txt_matrices(topk)

    def compute_topic_diversity(self, topk):
        topic_list = self.export_topic_word_topk_words(topk)
        topic_set_list = [topic.split() for topic in topic_list]
        n_topic = len(topic_set_list)
        tu=0.0
        for topic_i in topic_set_list:
            tu_k=0.0
            for word in topic_i:
                cnt=0.0
                for topic_j in topic_set_list:
                    if word in topic_j:
                        cnt+=1.0
                tu_k += 1.0/cnt
            tu_k = tu_k / len(topic_i)
            tu += tu_k
        tu_out = tu/(1.0*n_topic)
        return tu_out, topic_list

    def get_topic_diversity(self, topic_word_list, topk=10):
        n_topics = len(topic_word_list)
        word_cnt_dict = {}
        for topic in topic_word_list:
            word_list = topic.split()
            for word in word_list:
                if word in word_cnt_dict.keys():
                    word_cnt_dict[word] += 1
                else:
                    word_cnt_dict[word] = 1
        n_repeat_topic_word = sum([v-1 for k,v in word_cnt_dict.items()])
        return 1.0 - float(n_repeat_topic_word) / (n_topics * topk)

    def WETC(self, topicmat, wordembeddings, topk=10):
        wetc = 0.0
        topicmat=topicmat.detach()
        K = len(topicmat)
        V = len(topicmat[0])
        topic_wordid_list = []
        cosine = torch.nn.CosineSimilarity(dim=1, eps=1e-08)
        for topic in topicmat:
            wordid_list = []
            tmp_list=[]
            word_cnt = 1
            # Construct <wordid, prob> pairs
            for index, value in enumerate(topic):
                tmp_list.append((index, value))
            # Descently sort the list
            sorted_list = sorted(tmp_list, key = lambda s:s[1], reverse=True)
            for pair in sorted_list:
                if word_cnt > topk:
                    break            
                tokenid = int(pair[0])
                wordid_list.append(tokenid)
                word_cnt += 1
            topic_wordid_list.append(wordid_list)
        # Compute WETC based on previously topic_word_id_list
        for topic in topic_wordid_list:
            for idi, wordi in enumerate(topic):
                for idj in range(idi+1, topk):
                    if idj+1>topk:
                        break
                    u = wordembeddings[topic[idi]].unsqueeze(0)
                    v = wordembeddings[topic[idj]].unsqueeze(0)
                    assert len(u)==len(v), "Unequal size of two vector in CosineSimilarity"
                    wetc += cosine(u, v).cpu()
        return wetc/(K*topk*(topk-1)/2.0) 
#=================================================================================================================

            