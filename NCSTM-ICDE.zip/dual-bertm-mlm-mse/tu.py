# -*- coding: utf-8 -*-
import argparse, sys, os
import numpy as np
import pickle

#==================================================================================================================
def tu_score_at(topic_set_list, topk=10):
    topic_n = len(topic_set_list)
    tu=0.0
    for topic_i in topic_set_list:
        tu_k=0.0
        for word in topic_i:
            cnt=0.0
            for topic_j in topic_set_list:
                if word in topic_j:
                    cnt+=1.0
            tu_k += 1.0/cnt
        tu_k = tu_k / len(topic_i)
        tu += tu_k
    tu_out = tu/(1.0*topic_n)
    return tu_out
#==================================================================================================================

def main(argv):
    if len(argv)<2:
        os._exit(0)
    else:
        filename = str(argv[1])
    tu_score_list=[]
    with open(filename, 'r', encoding='utf-8') as fp:
        content = fp.readlines()
        for k in (10, 20, 25, 30, 40, 50, 60, 70, 80, 90, 100):
            topic_set_list = [topic.strip().split()[:k] for topic in content]
            tu_k = tu_score_at(topic_set_list, k)
            tu_score_list.append(tu_k)
            print("Topic uniquness at %d: %4f" % (k, tu_k))


if __name__ == '__main__':
    main(sys.argv)
